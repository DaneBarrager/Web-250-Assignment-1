<?php include '../view/header2.php';
global $error;

?>
<link rel="stylesheet" type="text/css" href="../styles/main.css">

<main>
    <h1>Error</h1>
    <p><?php echo $error; ?></p>
</main>
<?php include '../view/footer.php'; ?>
